import React from "react";
import Reactdom from "react-dom";
import App from "./components/App";

Reactdom.render(
  <div>
    <div class="hello">
      <button type="home" class="cat">
        Home{" "}
      </button>
      <button type="About" class="dog">
        About
      </button>
      <button type="Contact Us" class="bird">
        Contact Us
      </button>
      <button type="sign in" class="fly">
        Sign In
      </button>
    </div>

    <App />
  </div>,
  document.getElementById("root")
);
